import 'package:flutter/material.dart';


class CardapioMenuView extends StatefulWidget {
  const CardapioMenuView({super.key});

  @override
  State<CardapioMenuView> createState() => _CardapioMenuViewState();
}

class _CardapioMenuViewState extends State<CardapioMenuView> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.brown,
        title: const Text('Menu de operações cardapio.', 
        style: TextStyle(
          color: Colors.white,
        ),
        ),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(
            Icons.exit_to_app,
            color: Colors.white,
            ),
            tooltip: 'sair',
            onPressed: () {
              Navigator.pushReplacementNamed(context, 'menu');
            },
          ),
        ],
      ),

  body: Stack(
    children: [
        Container(
          decoration:const BoxDecoration(
              image: DecorationImage(
                fit: BoxFit.cover,
                image: NetworkImage(("https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmVzdGF1cmFudHxlbnwwfHwwfHx8MA%3D%3D")
                ),
              ),
            ),
        ),
        Container(
          decoration:  BoxDecoration(
              color: Colors.black.withOpacity(0.8),
              backgroundBlendMode: BlendMode.color,                       
            ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,            
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.brown,
                  fixedSize: const Size(300,150),
                  shape:RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ), 
                onPressed: (){
                  Navigator.pushNamed(context, 'cardapio');
                },
                child: const Text('Listar, adicionar, editar e remover',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 25),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.brown,
                  fixedSize: const Size(300,150),
                  shape:RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ), 
                onPressed: (){
                  Navigator.pushNamed(context, 'cardapioSearch');
                },
                child: const Text('Busca por id',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                ),
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  ],
  ),
  
    );
  }
}
