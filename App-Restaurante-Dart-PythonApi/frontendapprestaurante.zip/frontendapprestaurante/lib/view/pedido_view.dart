import 'package:flutter/material.dart';
import '../model/pedidos.dart';
import '../service/api_restaurante.dart';
import 'dart:convert' show utf8;

class PedidoView extends StatefulWidget {
  const PedidoView({super.key});

  @override
  State<PedidoView> createState() => _PedidoViewState();
}

class _PedidoViewState extends State<PedidoView> {
var txtMesa = TextEditingController();
var txtIdprato = TextEditingController();
var id;
@override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.brown,
        title: const Text('Pedidos', 
        style: TextStyle(
          color: Colors.white,
        ),
        ),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(
            Icons.add,
            color: Colors.white,
            ),
            tooltip: 'adicionar',
            onPressed: () {
              adicionarPrato();
            },
          ),
          IconButton(
            icon: const Icon(
            Icons.exit_to_app,
            color: Colors.white,
            ),
            tooltip: 'sair',
            onPressed: () {
              Navigator.pushReplacementNamed(context, 'pedidosMenu');
            },
          ),
        ],
      ),     
      body: Stack(
      children: [
      Container(
          decoration: const BoxDecoration(      
              image: DecorationImage(
                fit: BoxFit.cover,
                image: NetworkImage(("https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmVzdGF1cmFudHxlbnwwfHwwfHx8MA%3D%3D")
                ),
              ),
            ),
        ),      
      Container(
          decoration:  BoxDecoration(
              color: Colors.black.withOpacity(0.8),
              backgroundBlendMode: BlendMode.color,                       
            ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          //
          // Requisição da API
          //
          child: FutureBuilder(
            future: ApiRestaurante().listarPedido(),
            builder: (context, snapshot) {
              //Requisição finalizada
              if (snapshot.connectionState == ConnectionState.done) {
                if(snapshot.hasData){
                var lista = snapshot.data as List<Pedidos>;
                return ListView.builder(
                  itemCount: lista.length,
                  itemBuilder: (context, index) {
                    String utf8Encmesa = lista[index].mesa;
                    var utf8Runesmesa = utf8Encmesa.runes.toList();

                    return Card(
                      child: ListTile(
                        title: Text(utf8.decode(utf8Runesmesa)),
                        subtitle: Text('Id do prato: ${lista[index].id_prato}'),

                      trailing:Wrap(
                        spacing: 10,
                        children: <Widget>[
                          IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () {
                                String utf8Encmesa = lista[index].mesa;
                                var utf8Runesmesa = utf8Encmesa.runes.toList();
                                
                                txtMesa.text = utf8.decode(utf8Runesmesa);
                                txtIdprato.text = lista[index].id_prato.toString();
                                id = lista[index].id;
                                editarPedido(context, id: id);
                             },
                            ),
                          IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: () {
                                 ApiRestaurante().removerPedido(context, lista[index].id); 
                             },
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
                }else{
                  return const Text('erro');
                }
        
              }
        
              //Aguardando a requisição
              return const Center(child: CircularProgressIndicator());
              
            },
          ),
        ),
      ),
      ],
     ),
    );
  }
  void editarPedido(context, {id}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // retorna um objeto do tipo Dialog
        return AlertDialog(
          title: const Text("Editar Pedido"),
          content: SizedBox(
            height: 250,
            width: 300,
            child: Column(
              children: [
              TextField(
                  controller: txtMesa,
                  decoration: const InputDecoration(
                    labelText: 'Mesa',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 15),
                TextField(
                  controller: txtIdprato,
                  decoration: const InputDecoration(
                    labelText: 'Id do prato',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          actionsPadding: EdgeInsets.fromLTRB(20, 0, 20, 10),
          actions: [
            TextButton(
              child: const Text("fechar"),
              onPressed: () {
                txtMesa.clear();
                txtIdprato.clear();
                Navigator.of(context).pop();
              },
            ),
            ElevatedButton(
              child: const Text("salvar"),
              onPressed: () {
                //criar objeto Pedidos
                var p = Pedidos(
                  txtMesa.text,
                  int.parse(txtIdprato.text),
                  id,
                );

                txtMesa.clear();
                txtIdprato.clear();

                ApiRestaurante().salvarPedido(p);
                Navigator.popUntil(context, ModalRoute.withName('pedidosMenu'));
              },
            ),
          ],
        );
      },
    );
  }
  void adicionarPrato() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // retorna um objeto do tipo Dialog
        return AlertDialog(
          title: const Text("Adicionar pedido"),
          content: SizedBox(
            height: 250,
            width: 300,
            child: Column(
              children: [
              TextField(
                  controller: txtMesa,
                  decoration: const InputDecoration(
                    labelText: 'Mesa',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 15),
                TextField(
                  controller: txtIdprato,
                  decoration: const InputDecoration(
                    labelText: 'Id do prato',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
          actions: [
            TextButton(
              child: const Text("fechar"),
              onPressed: () {
                txtMesa.clear();
                txtIdprato.clear();
                Navigator.of(context).pop();
              },
            ),
            ElevatedButton(
              child: const Text("salvar"),
              onPressed: () {
                //criar objeto Pedidos
                var p = Pedidos(
                  txtMesa.text,
                  int.parse(txtIdprato.text),
                  id = 0,
                );

                txtMesa.clear();
                txtIdprato.clear();

                ApiRestaurante().salvarPedido(p);
                Navigator.popUntil(context, ModalRoute.withName('pedidosMenu'));
              },
            ),
          ],
        );
      },
    );
  }
}
