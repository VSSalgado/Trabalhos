import 'package:flutter/material.dart';

class SobreView extends StatefulWidget {
  const SobreView({super.key});

  @override
  State<SobreView> createState() => _SobreViewState();
}

class _SobreViewState extends State<SobreView> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.brown,
        title: const Text('Sobre', 
        style: TextStyle(
          color: Colors.white,
        ),
        ),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(
            Icons.exit_to_app,
            color: Colors.white,
            ),
            tooltip: 'sair',
            onPressed: () {
              Navigator.pushReplacementNamed(context, 'menu');
            },
          ),
        ],
      ),

  body: Stack(
    children: [
        Container(
          decoration:const BoxDecoration(
              image: DecorationImage(
                fit: BoxFit.cover,
                image: NetworkImage(("https://as2.ftcdn.net/v2/jpg/00/33/89/97/1000_F_33899713_jOBwdtrgVAmhODmHHGBqoBdlwFmVN6dx.jpg")
                ),
              ),
            ),
        ),
      Container(
      padding: const EdgeInsets.fromLTRB(50, 50, 50, 50),
      child: const Column(
       mainAxisAlignment: MainAxisAlignment.center,
        children: [        
              Text(
                'Projeto final tema "Restaurante", aplicativo Front-End para API de um restaurante.',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 30,
                ),
              ),
              Text(
                'Vinícius dos Santos Salgado - 836612',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 30,
                ),
              ),
        ],
      ),
    ),
  ],
  ),
  
    );
  }
}
