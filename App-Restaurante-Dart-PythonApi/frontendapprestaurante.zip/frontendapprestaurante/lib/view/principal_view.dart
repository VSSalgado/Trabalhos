import 'package:flutter/material.dart';


class PrincipalView extends StatefulWidget {
  const PrincipalView({super.key});

  @override
  State<PrincipalView> createState() => _PrincipalViewState();
}

class _PrincipalViewState extends State<PrincipalView> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.brown,
        title: const Text('Menu', 
        style: TextStyle(
          color: Colors.white,
        ),
        ),
        automaticallyImplyLeading: false,
      ),

  body: Stack(
    children: [
        Container(
          decoration:const BoxDecoration(
              image: DecorationImage(
                fit: BoxFit.cover,
                image: NetworkImage(("https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmVzdGF1cmFudHxlbnwwfHwwfHx8MA%3D%3D")
                ),
              ),
            ),
        ),
        Container(
          decoration:  BoxDecoration(
              color: Colors.black.withOpacity(0.8),
              backgroundBlendMode: BlendMode.color,                       
            ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,            
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.brown,
                  fixedSize: const Size(300,150),
                  shape:RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ), 
                onPressed: (){
                  Navigator.pushNamed(context, 'cardapioMenu');
                },
                child: const Text('Operações cardapio',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 25),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.brown,
                  fixedSize: const Size(300,150),
                  shape:RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                  ),
                ), 
                onPressed: (){
                   Navigator.pushNamed(context, 'pedidosMenu');
                },
                child: const Text('Operações pedidos',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 25),
          Row(          
            mainAxisAlignment: MainAxisAlignment.center,
            
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.brown,
                  fixedSize: const Size(300,150),
                  shape:RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ), 
                onPressed: (){
                  Navigator.pushNamed(context, 'sobre');
                },
                child: const Text('Sobre',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                ),
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  ],
  ),
  
    );
  }
}
