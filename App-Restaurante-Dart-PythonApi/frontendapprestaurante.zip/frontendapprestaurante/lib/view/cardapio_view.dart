import 'package:flutter/material.dart';
import '../model/cardapio.dart';
import '../service/api_restaurante.dart';
import 'dart:convert' show utf8;

class CardapioView extends StatefulWidget {
  const CardapioView({super.key});

  @override
  State<CardapioView> createState() => _CardapioViewState();
}

class _CardapioViewState extends State<CardapioView> {
var txtPrato = TextEditingController();
var txtDescricao = TextEditingController();
var id;
@override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.brown,
        title: const Text('Cardápio', 
        style: TextStyle(
          color: Colors.white,
        ),
        ),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(
            Icons.add,
            color: Colors.white,
            ),
            tooltip: 'adicionar',
            onPressed: () {
              adicionarPrato();
            },
          ),
          IconButton(
            icon: const Icon(
            Icons.exit_to_app,
            color: Colors.white,
            ),
            tooltip: 'sair',
            onPressed: () {
              Navigator.pushReplacementNamed(context, 'cardapioMenu');
            },
          ),
        ],
      ),     
      body: Stack(
      children: [
      Container(
          decoration: const BoxDecoration(      
              image: DecorationImage(
                fit: BoxFit.cover,
                image: NetworkImage(("https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmVzdGF1cmFudHxlbnwwfHwwfHx8MA%3D%3D")
                ),
              ),
            ),
        ),      
      Container(
          decoration:  BoxDecoration(
              color: Colors.black.withOpacity(0.8),
              backgroundBlendMode: BlendMode.color,                       
            ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          //
          // Requisição da API
          //
          child: FutureBuilder(
            future: ApiRestaurante().listarCardapio(),
            builder: (context, snapshot) {
              //Requisição finalizada
              if (snapshot.connectionState == ConnectionState.done) {
                if(snapshot.hasData){
                var lista = snapshot.data as List<Cardapio>;
                return ListView.builder(
                  itemCount: lista.length,
                  itemBuilder: (context, index) {
                    String utf8Encpratos = lista[index].prato;
                    var utf8Runespratos = utf8Encpratos.runes.toList();
                    String utf8Encdesc = lista[index].descricao;
                    var utf8Runesdesc = utf8Encdesc.runes.toList();
                    return Card(
                      child: ListTile(
                        title: Text(utf8.decode(utf8Runespratos)),
                        subtitle: Text('Descrição: ${utf8.decode(utf8Runesdesc)}'),

                      trailing:Wrap(
                        spacing: 10,
                        children: <Widget>[
                          IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () {
                                String utf8Encpratos = lista[index].prato;
                                var utf8Runespratos = utf8Encpratos.runes.toList();

                                String utf8Encdesc = lista[index].descricao;
                                var utf8Runesdesc = utf8Encdesc.runes.toList();
                                
                                txtPrato.text = utf8.decode(utf8Runespratos);
                                txtDescricao.text = utf8.decode(utf8Runesdesc);
                                id = lista[index].id;
                                editarPrato(context, id: id);
                             },
                            ),
                          IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: () {
                                 ApiRestaurante().removerCardapio(context, lista[index].id); 
                             },
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
                }else{
                  return const Text('erro');
                }
        
              }
        
              //Aguardando a requisição
              return const Center(child: CircularProgressIndicator());
              
            },
          ),
        ),
      ),
      ],
     ),
    );
  }
  void editarPrato(context, {id}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // retorna um objeto do tipo Dialog
        return AlertDialog(
          title: const Text("Editar Prato"),
          content: SizedBox(
            height: 250,
            width: 300,
            child: Column(
              children: [
              TextField(
                  controller: txtPrato,
                  decoration: const InputDecoration(
                    labelText: 'Prato',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 15),
                TextField(
                  controller: txtDescricao,
                  decoration: const InputDecoration(
                    labelText: 'Descrição',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          actionsPadding: EdgeInsets.fromLTRB(20, 0, 20, 10),
          actions: [
            TextButton(
              child: const Text("fechar"),
              onPressed: () {
                txtPrato.clear();
                txtDescricao.clear();
                Navigator.of(context).pop();
              },
            ),
            ElevatedButton(
              child: const Text("salvar"),
              onPressed: () {
                //criar objeto Cardapio
                var p = Cardapio(
                  txtPrato.text,
                  txtDescricao.text,
                  id,
                );

                txtPrato.clear();
                txtDescricao.clear();

                ApiRestaurante().salvarCardapio(p);
                Navigator.popUntil(context, ModalRoute.withName('cardapioMenu'));
              },
            ),
          ],
        );
      },
    );
  }
  void adicionarPrato() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // retorna um objeto do tipo Dialog
        return AlertDialog(
          title: const Text("Adicionar Prato"),
          content: SizedBox(
            height: 250,
            width: 300,
            child: Column(
              children: [
              TextField(
                  controller: txtPrato,
                  decoration: const InputDecoration(
                    labelText: 'Prato',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 15),
                TextField(
                  controller: txtDescricao,
                  decoration: const InputDecoration(
                    labelText: 'Descrição',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
          actions: [
            TextButton(
              child: const Text("fechar"),
              onPressed: () {
                txtPrato.clear();
                txtDescricao.clear();
                Navigator.of(context).pop();
              },
            ),
            ElevatedButton(
              child: const Text("salvar"),
              onPressed: () {
                //criar objeto Cardapio
                var p = Cardapio(
                  txtPrato.text,
                  txtDescricao.text,
                  id = 0,
                );

                txtPrato.clear();
                txtDescricao.clear();

                ApiRestaurante().salvarCardapio(p);
                Navigator.popUntil(context, ModalRoute.withName('cardapioMenu'));
              },
            ),
          ],
        );
      },
    );
  }
}
