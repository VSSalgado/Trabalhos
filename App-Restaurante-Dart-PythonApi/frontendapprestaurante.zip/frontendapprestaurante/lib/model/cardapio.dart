class Cardapio {
  final String prato;
  final String descricao;
  final int id;

  Cardapio(this.prato, this.descricao, this.id);

  factory Cardapio.fromJson(Map json) {
    return Cardapio(
      json['prato'],
      json['descricao'],
      json['id']
    );
  }
}
