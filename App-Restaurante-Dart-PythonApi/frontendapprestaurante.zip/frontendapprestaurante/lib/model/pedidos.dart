class Pedidos {
  final String mesa;
  final int id_prato;
  final int id;

  Pedidos(this.mesa, this.id_prato, this.id);

  factory Pedidos.fromJson(Map json) {
    return Pedidos(
      json['mesa'],
      json['id_prato'],
      json['id']
    );
  }
}
