import 'package:device_preview/device_preview.dart';
import 'package:flutter/material.dart';
import '../view/principal_view.dart';
import '../view/sobre_view.dart';
import '../view/cardapio_view.dart';
import '../view/cardapio_menu_view.dart';
import '../view/cardapio_search_view.dart';
import '../view/pedido_view.dart';
import '../view/pedido_search_view.dart';
import '../view/pedido_menu_view.dart';

Future<void> main() async{
  runApp(
    DevicePreview(
      enabled: false,
      builder: (context) => const MainApp(),
    ),
  );
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Restaurante front end API',
      initialRoute: 'menu',
      routes: {
        'menu': (context) => PrincipalView(),
        'sobre': (context) => SobreView(),
        'cardapio': (context) => CardapioView(),
        'cardapioSearch': (context) => CardapioSearchView(),
        'cardapioMenu': (context) => CardapioMenuView(),
        'pedidos': (context) => PedidoView(),
        'pedidoSearch': (context) => PedidoSearchView(),
        'pedidosMenu': (context) => PedidoMenuView(),
      },
    );
  }
}
