import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../model/cardapio.dart';
import '../model/pedidos.dart';

class ApiRestaurante {
  //
  // Retornar a lista de pratos
  //
  Future<List<Cardapio>> listarCardapio() async {
    var resposta = await http.get(
      Uri.parse(
        'http://localhost:8000/api/Cardapio2' 
      ) 
    );

    if (resposta.statusCode == 200) {
      Iterable lista = json.decode(resposta.body);
      return lista.map((modelo) => Cardapio.fromJson(modelo)).toList();
    } else {
      return [];
    }    
  }

  //
  // Retornar prato por id
  //
  Future<Cardapio> listarCardapioporId(id) async {
  try{
    var resposta = await http.get(
      Uri.parse(
        'http://localhost:8000/api/Cardapio1/'+id.toString()
      ) 
    );
      if(resposta.statusCode == 200){
        return Cardapio.fromJson(json.decode(resposta.body));
      }
      throw Exception('Item não encontrado');
    } catch (e) {
      throw Exception('ERRO');
    }
  }

  //
  // Salvar prato
  //
  Future salvarCardapio(Cardapio p) async {
    if(p.id == 0){
    await http.post(Uri.parse('http://localhost:8000/api/Cardapio1'), 
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8'
        },
        body: jsonEncode(<String, String>{
          'prato': p.prato,
          'descricao': p.descricao
        })
     );
    }else{
    await http.put(Uri.parse('http://localhost:8000/api/Cardapio3/'+p.id.toString()), 
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8'
        },
        body: jsonEncode(<String, String>{
          'prato': p.prato,
          'descricao': p.descricao
        })
     );
    }
  }

  //
  // Remover prato
  //
  Future removerCardapio(context, id) async {
    var resposta = await http.delete(
      Uri.parse(
        'http://localhost:8000/api/Cardapio3/'+id.toString() 
      ) 
    );

    if (resposta.statusCode == 200) {
      showDialog(
        context: context, 
        builder: (BuildContext context) {
        // retorna um objeto do tipo Dialog
        return AlertDialog(
          title: const Text("Prato Removido com sucesso"),
          actionsPadding: EdgeInsets.fromLTRB(20, 0, 20, 10),
          actions: [
            TextButton(
              child: const Text("Ok"),
              onPressed: () {
                Navigator.popUntil(context, ModalRoute.withName('cardapioMenu'));
              },
            ),
          ],
        );
      },       
      );
    } else {
      showDialog(
        context: context, 
        builder: (BuildContext context) {
        // retorna um objeto do tipo Dialog
        return AlertDialog(
          title: const Text("ERRO"),
          actionsPadding: EdgeInsets.fromLTRB(20, 0, 20, 10),
          actions: [
            TextButton(
              child: const Text("Ok"),
              onPressed: () {
                Navigator.popUntil(context, ModalRoute.withName('cardapioMenu'));
              },
            ),
          ],
        );
      },       
      );
    }
  }

  //
  // Retornar a lista de pedidos
  //
  Future<List<Pedidos>> listarPedido() async {
    var resposta = await http.get(
      Uri.parse(
        'http://127.0.0.1:8000/api/Pedidos' 
      ) 
    );

    if (resposta.statusCode == 200) {
      Iterable lista = json.decode(resposta.body);
      return lista.map((modelo) => Pedidos.fromJson(modelo)).toList();
    } else {
      return [];
    }    
  }

  //
  // Retornar pedido por id
  //
  Future<Pedidos> listarPedidoporId(id) async {
  try{
    var resposta = await http.get(
      Uri.parse(
        'http://127.0.0.1:8000/api/Pedidos/'+id.toString()
      ) 
    );
      if(resposta.statusCode == 200){
        return Pedidos.fromJson(json.decode(resposta.body));
      }
      throw Exception('Item não encontrado');
    } catch (e) {
      throw Exception('ERRO');
    }
  }

  //
  // Salvar pedido
  //
  Future salvarPedido(Pedidos p) async {
    if(p.id == 0){
    await http.post(Uri.parse('http://127.0.0.1:8000/api/Pedidos'), 
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8'
        },
        body: jsonEncode(<String, String>{
          'mesa': p.mesa,
          'id_prato': p.id_prato.toString()
        })
     );
    }else{
    await http.put(Uri.parse('http://127.0.0.1:8000/api/Pedidos/'+p.id.toString()), 
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8'
        },
        body: jsonEncode(<String, String>{
          'mesa': p.mesa,
          'id_prato': p.id_prato.toString()
        })
     );
    }
  }

  //
  // Remover pedido
  //
  Future removerPedido(context, id) async {
    var resposta = await http.delete(
      Uri.parse(
        'http://127.0.0.1:8000/api/Pedidos/'+id.toString() 
      ) 
    );

    if (resposta.statusCode == 200) {
      showDialog(
        context: context, 
        builder: (BuildContext context) {
        // retorna um objeto do tipo Dialog
        return AlertDialog(
          title: const Text("Pedido Removido com sucesso"),
          actionsPadding: EdgeInsets.fromLTRB(20, 0, 20, 10),
          actions: [
            TextButton(
              child: const Text("Ok"),
              onPressed: () {
                Navigator.popUntil(context, ModalRoute.withName('pedidosMenu'));
              },
            ),
          ],
        );
      },       
      );
    } else {
      showDialog(
        context: context, 
        builder: (BuildContext context) {
        // retorna um objeto do tipo Dialog
        return AlertDialog(
          title: const Text("ERRO"),
          actionsPadding: EdgeInsets.fromLTRB(20, 0, 20, 10),
          actions: [
            TextButton(
              child: const Text("Ok"),
              onPressed: () {
                Navigator.popUntil(context, ModalRoute.withName('pedidosMenu'));
              },
            ),
          ],
        );
      },       
      );
    }
  }
}