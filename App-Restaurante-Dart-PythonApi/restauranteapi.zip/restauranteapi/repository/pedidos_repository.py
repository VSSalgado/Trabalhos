from __future__ import annotations
from sqlalchemy.orm import Session
from models.pedidos import Pedidos

class PedidosRepository:

    # Retornar todas as reservas
    @staticmethod
    def get_all(db:Session) -> list[Pedidos]:
        return db.query(Pedidos).all()
    
    # Salvar uma reserva na tabela
    @staticmethod
    def salvar(db:Session, Pedidos: Pedidos) -> Pedidos:
        if (Pedidos.id):
            db.merge(Pedidos)
        else:
            db.add(Pedidos)
        db.commit()
        return Pedidos

    # Retornar uma reserva a partir do Id
    @staticmethod
    def get_by_id(db:Session, id: int) -> Pedidos:
        return db.query(Pedidos).filter(Pedidos.id == id).first()

    # Verificar se uma reserva existe a partir do Id
    @staticmethod
    def exists_by_id(db:Session, id: int) -> bool:
        return db.query(Pedidos).filter(Pedidos.id == id).first() is not None
    
    # Apagar uma reserva a partir do Id
    @staticmethod
    def deletar(db:Session, id: int) -> bool:
        pedido = db.query(Pedidos).filter(Pedidos.id == id).first()
        if pedido is not None:
            db.delete(pedido)
            db.commit()
            return True
        return False