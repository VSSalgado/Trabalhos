from __future__ import annotations
from sqlalchemy.orm import Session
from models.cardapio import Cardapio

class CardapioRepository:

    # Retornar todos os pratos
    @staticmethod
    def get_all(db:Session) -> list[Cardapio]:
        return db.query(Cardapio).all()
    
    # Salvar um prato na tabela
    @staticmethod
    def salvar(db:Session, Cardapio: Cardapio) -> Cardapio:
        if (Cardapio.id):
            db.merge(Cardapio)
        else:
            db.add(Cardapio)
        db.commit()
        return Cardapio

    # Retornar um prato a partir do Id
    @staticmethod
    def get_by_id(db:Session, id: int) -> Cardapio:
        return db.query(Cardapio).filter(Cardapio.id == id).first()
    
    # Verificar se um prato existe a partir do Id
    @staticmethod
    def exists_by_id(db:Session, id: int) -> bool:
        return db.query(Cardapio).filter(Cardapio.id == id).first() is not None
    
    # Apagar um prato a partir do Id
    @staticmethod
    def deletar(db:Session, id: int) -> bool:
        cardapio = db.query(Cardapio).filter(Cardapio.id == id).first()
        if cardapio is not None:
            db.delete(cardapio)
            db.commit()
            return True
        return False