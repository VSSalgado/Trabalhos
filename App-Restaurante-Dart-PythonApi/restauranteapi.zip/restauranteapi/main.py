from __future__ import annotations
from fastapi import FastAPI, Depends, HTTPException, status
from sqlalchemy.orm import Session
from models.cardapio import Cardapio, CardapioResponse, CardapioRequest
from models.pedidos import Pedidos, PedidosResponse, PedidosRequest
from data.config import engine, Base, get_db
from repository.cardapio_repository import CardapioRepository
from repository.pedidos_repository import PedidosRepository
from fastapi.middleware.cors import CORSMiddleware

Base.metadata.create_all(bind=engine)
app = FastAPI(
    title="API Restaurante",
    description="API de cardapio e pedidos para restaurantes",
)

origins = ['*',]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


#
# Rotas Cardapio
#
@app.post("/api/Cardapio1", response_model=CardapioResponse, status_code=status.HTTP_201_CREATED, tags=["Operações cardapio"])
def inserir(request: CardapioRequest, db:Session = Depends(get_db)):
    '''
    Inserir um prato no cardapio
    '''
    return CardapioRepository.salvar(db,Cardapio(**request.model_dump()))

@app.get("/api/Cardapio1/{id}", response_model=CardapioResponse, tags=["Operações cardapio"])
def get_by_id(id: int, db:Session = Depends(get_db)):
    '''
    Procurar um prato por id do cardapio
    '''
    cardapio = CardapioRepository.get_by_id(db,id)
    if (not cardapio):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail='Prato não encontrado.')
    return cardapio

@app.get("/api/Cardapio2", response_model=list[CardapioResponse], tags=["Operações cardapio"])
def listar(db:Session = Depends(get_db)):
    '''
    Listar todos os pratos no cardapio
    '''
    return CardapioRepository.get_all(db)

@app.delete("/api/Cardapio3/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Operações cardapio"])
def deletar(id: int, db:Session = Depends(get_db)):
    '''
    Remover um prato do cardapio
    '''
    if not CardapioRepository.exists_by_id(db,id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail='Prato não encontrado.')
    
    if CardapioRepository.deletar(db,id):
        raise HTTPException(status_code=status.HTTP_200_OK,detail='Operação realizada com sucesso!')
    else:
        raise HTTPException(status_code=status.HTTP_200_OK,detail='Não foi possível realizar a operação.')

@app.put("/api/Cardapio3/{id}", response_model=CardapioResponse, tags=["Operações cardapio"])
def atualizar(id: int, request: CardapioRequest, db:Session = Depends(get_db)):
    '''
    Atualizar as informações de um prato no cardapio
    '''
    if not CardapioRepository.exists_by_id(db,id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail='Prato não encontrado.')
    
    return CardapioRepository.salvar(db, Cardapio(id=id,**request.model_dump()))

#
# Rotas Reservas
#
@app.post("/api/Pedidos", response_model=PedidosResponse, status_code=status.HTTP_201_CREATED, tags=["Operações pedidos"])
def inserir(request: PedidosRequest, db:Session = Depends(get_db)):
    '''
    Inserir um pedido
    '''
    return PedidosRepository.salvar(db,Pedidos(**request.model_dump()))

@app.get("/api/Pedidos", response_model=list[PedidosResponse], tags=["Operações pedidos"])
def listar(db:Session = Depends(get_db)):
    '''
    Listar todos os pedidos
    '''
    return PedidosRepository.get_all(db)

@app.get("/api/Pedidos/{id}", response_model=PedidosResponse, tags=["Operações pedidos"])
def get_by_id(id: int, db:Session = Depends(get_db)):
    '''
    Procurar um pedido por id
    '''
    pedido = PedidosRepository.get_by_id(db,id)
    if (not pedido):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail='Pedido não encontrado.')
    return pedido

@app.delete("/api/Pedidos/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Operações pedidos"])
def deletar(id: int, db:Session = Depends(get_db)):
    '''
    Remover um pedido
    '''
    if not PedidosRepository.exists_by_id(db,id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail='Pedido não encontrado.')
    
    if PedidosRepository.deletar(db,id):
        raise HTTPException(status_code=status.HTTP_200_OK,detail='Operação realizada com sucesso!')
    else:
        raise HTTPException(status_code=status.HTTP_200_OK,detail='Não foi possível realizar a operação.')

@app.put("/api/Pedidos/{id}", response_model=PedidosResponse, tags=["Operações pedidos"])
def atualizar(id: int, request: PedidosRequest, db:Session = Depends(get_db)):
    '''
    Atualizar as informações de um pedido
    '''
    if not PedidosRepository.exists_by_id(db,id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail='Pedido não encontrado.')
    
    return PedidosRepository.salvar(db, Pedidos(id=id,**request.model_dump()))
            
