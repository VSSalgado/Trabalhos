from sqlalchemy import Column, Integer, String, ForeignKey
from data.config import Base
from pydantic import BaseModel
from models.cardapio import Cardapio

class Pedidos(Base):
    __tablename__ = "Pedidos"

    id: int = Column(Integer, primary_key=True, index=True)
    mesa: str = Column(String(10), unique=True, nullable=False)
    id_prato: int = Column(Integer, ForeignKey(Cardapio.id), nullable=False)

class PedidosBase(BaseModel):
    mesa: str
    id_prato: int

class PedidosRequest(PedidosBase):
    ...

class PedidosResponse(PedidosBase):
    id: int

    class Config:
        from_attributes = True
        populate_by_name = True