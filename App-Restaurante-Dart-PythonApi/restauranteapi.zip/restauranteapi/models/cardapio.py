from sqlalchemy import Column, Integer, String
from data.config import Base
from pydantic import BaseModel

class Cardapio(Base):
    __tablename__ = "Cardapio"

    id: int = Column(Integer, primary_key=True, index=True)
    prato: str = Column(String(40), unique=True, nullable=False)
    descricao: str = Column(String(200), nullable=False)

class CardapioBase(BaseModel):
    prato: str
    descricao: str

class CardapioRequest(CardapioBase):
    ...

class CardapioResponse(CardapioBase):
    id: int
    
    class Config:
        from_attributes = True
        populate_by_name = True